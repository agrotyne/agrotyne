import Head from "next/head";

export default function Home() {
  return (
    <div className="bg-gray-100 text-gray-800 font-sans min-h-screen">
      <Head>
        <title>Agrotyne | Organic Agritech Consultancy</title>
        <meta
          name="description"
          content="Agrotyne is a modern agritech consultancy specializing in indoor farming, greenhouse design, and sustainable organic solutions."
        />
      </Head>

      <header className="bg-green-700 text-white p-6 shadow-md">
        <nav className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Agrotyne</h1>
            <p className="text-sm">Minimal Land, Maximum Yield - Organically</p>
          </div>
          <ul className="flex space-x-6 text-white text-sm">
            <li><a href="#about" className="hover:underline">About</a></li>
            <li><a href="#services" className="hover:underline">Services</a></li>
            <li><a href="#contact" className="hover:underline">Contact</a></li>
          </ul>
        </nav>
      </header>

      <main className="p-6 space-y-10">
        <section id="about" className="space-y-4">
          <h2 className="text-2xl font-semibold text-green-800">About Us</h2>
          <div className="bg-white p-4 shadow rounded">
            <p>
              Agrotyne is a cutting-edge agritech consultancy focused on modern, organic
              farming solutions like indoor farming and greenhouse setups. We help
              farmers and agricultural businesses optimize land use and maximize yield
              sustainably.
            </p>
          </div>
        </section>

        <section id="services" className="space-y-4">
          <h2 className="text-2xl font-semibold text-green-800">Our Services</h2>
          <div className="bg-white p-4 shadow rounded">
            <ul className="list-disc pl-5 space-y-1">
              <li>Indoor Farming Consultancy</li>
              <li>Greenhouse Design & Setup</li>
              <li>Organic Crop Planning</li>
              <li>Soil-less Farming Techniques</li>
              <li>Vertical Farming Strategies</li>
            </ul>
          </div>
        </section>

        <section id="contact" className="space-y-4">
          <h2 className="text-2xl font-semibold text-green-800">Contact Us</h2>
          <div className="bg-white p-4 shadow rounded">
            <form className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Name</label>
                <input type="text" placeholder="Your Name" className="w-full border border-gray-300 rounded p-2" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Email</label>
                <input type="email" placeholder="you@example.com" className="w-full border border-gray-300 rounded p-2" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Message</label>
                <textarea placeholder="Tell us how we can help..." rows="4" className="w-full border border-gray-300 rounded p-2" />
              </div>
              <button className="bg-green-700 text-white px-4 py-2 rounded hover:bg-green-800">
                Send Message
              </button>
            </form>
          </div>
        </section>
      </main>

      <footer className="bg-gray-200 text-center p-4 mt-10 text-sm text-gray-600">
        © 2025 Agrotyne. All rights reserved.
      </footer>
    </div>
  );
}